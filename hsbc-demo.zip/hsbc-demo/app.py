from flask import Flask
from flask import request, render_template, redirect, url_for, session

from functools import wraps
import conf

app = Flask(__name__)

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        conf.userid = request.form['userid']
        return redirect("/login")
    else:
        return render_template('index.html')

@app.route('/logout', methods=['GET'])
def clean():
    return redirect("/")

# web login
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        pass2 = request.form.get("pass2", default=None)
        pass5 = request.form.get("pass5", default=None)
        pass7 = request.form.get("pass7", default=None)
        username = request.form.get("username", default=None)
        password = format("{}{}{}".format(pass2, pass5, pass7))
        pwd = request.form.get("password", default=None)
        if pass2 and pass5 and pass7 and username:
            if username == conf.username and password == conf.password:
                return render_template('detail.html',userid=conf.userid)
        elif username and pwd:
            if username == conf.username and pwd == conf.password:
                return render_template('detail.html',userid=conf.userid)
        else:
            return render_template('error.html')
    return render_template('login.html',userid=conf.userid)

@app.route('/error', methods=['GET'])
def error():
    return render_template('error.html')

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8080, debug=True)