var ADRUM_APP_KEY="";


var imported = document.createElement('script');
imported.src = '/static/js/adrum.js';
document.getElementsByTagName('head')[0].appendChild(imported);